# -*- coding: utf-8 -*-
"""
Created on Sat Dec 16 15:52:01 2017

@author: liang
"""

import pandas as pd
import numpy as np
def getWeight():
    w1=pd.read_csv('C:/Users/liang/Desktop/UTT/SY26/projet/w1.csv',encoding = 'gbk') #filename可以直接从盘符开始，标明每一级的文件夹直到csv文件，header=None表示头部为空，sep=' '表示数据间使用空格作为分隔符，如果分隔符是逗号，只需换成 ‘，’即可。
    w2=pd.read_csv('C:/Users/liang/Desktop/UTT/SY26/projet/w2.csv',encoding = 'gbk') #filename可以直接从盘符开始，标明每一级的文件夹直到csv文件，header=None表示头部为空，sep=' '表示数据间使用空格作为分隔符，如果分隔符是逗号，只需换成 ‘，’即可。
    b1=pd.read_csv('C:/Users/liang/Desktop/UTT/SY26/projet/b1.csv',encoding = 'gbk') #filename可以直接从盘符开始，标明每一级的文件夹直到csv文件，header=None表示头部为空，sep=' '表示数据间使用空格作为分隔符，如果分隔符是逗号，只需换成 ‘，’即可。
    b2=pd.read_csv('C:/Users/liang/Desktop/UTT/SY26/projet/b2.csv',encoding = 'gbk') #filename可以直接从盘符开始，标明每一级的文件夹直到csv文件，header=None表示头部为空，sep=' '表示数据间使用空格作为分隔符，如果分隔符是逗号，只需换成 ‘，’即可。
    w1 = w1.values
    w1 = np.delete(w1, 0 , axis =1)
    w2 = w2.values
    w2 = np.delete(w2, 0 , axis =1)
    b1 = b1.values
    b1 = np.delete(b1, 0 , axis =1)
    b2 = b2.values
    b2 = np.delete(b2, 0 , axis =1)
    return w1,w2,b1,b2
    

if __name__ == '__main__':  
    w1,w2,b1,b2 = getWeight()
    print(w1.shape)
    print(w2)
    print(b1)
    print(b2)