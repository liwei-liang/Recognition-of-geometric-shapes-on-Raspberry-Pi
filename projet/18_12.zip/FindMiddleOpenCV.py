# -*- coding: utf-8 -*-
"""
Created on Wed Dec 13 12:13:07 2017

@author: liang
"""

import cv2
import numpy as np  

'''
确定图片原始长宽
二值化
可以利用描边的那个方法contour
确定图形的身高和宽度
找到四个点在矩阵中的位置
对图像进行切割
然后再缩小成32*32
'''
def draw_contour(ImgPath):
    #img = Image.open(ImgPath)
    img =ImgPath
    blured = cv2.blur(img,(5,5))    #进行滤波去掉噪声
    gray = cv2.cvtColor(blured,cv2.COLOR_BGR2GRAY)
    #定义结构元素 
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(50, 50))
    #开闭运算，先开运算去除背景噪声，再继续闭运算填充目标内的孔洞
    opened = cv2.morphologyEx(gray, cv2.MORPH_OPEN, kernel) 
    closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, kernel)
    seuil=np.max(np.array(gray))/2+np.min(np.array(gray))/2-7
    ret, binary = cv2.threshold(gray, seuil, 255, cv2.THRESH_BINARY)#binaire les valeurs des pixel
    image ,contours,hierarchy= cv2.findContours(binary,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)  
    if len(contours) > 0:
        left, top, largeur, hauteur = cv2.boundingRect(contours[0])   
       #a= cv2.rectangle(image, (x,y), (x+w,y+h), (153,153,0), 5) 
        image_contour = cv2.drawContours(img,contours,0,(24,81,172),10)
        right = 0
        bot = 0
        print(left)
        print(top)
        print(hauteur)
        print(largeur)
        if hauteur > largeur:
            line_middle = largeur/2+left
            left = round(line_middle - hauteur/2)
            right = round(line_middle + hauteur/2)
            bot = top + hauteur
        elif hauteur <= largeur:
            col_middle = hauteur/2+top
            top = round(col_middle - largeur/2)
            bot = round(col_middle + largeur/2)
            right = left + largeur
        if(left<0):
            right = right - left
            left = 0
        if(top<0):
            bot = bot - top
            top = 0
        box = (left,top,right,bot) #设定裁剪区域  
        img_cut = binary[top:bot,left:right]  #裁剪图片，并获取句柄region  
        img_resized = cv2.resize(img_cut,(32, 32))
        return image_contour,img_resized,box
    else:
        return img,binary[0:32,0:32],(0,0,0,0)

    
    
    
    
    