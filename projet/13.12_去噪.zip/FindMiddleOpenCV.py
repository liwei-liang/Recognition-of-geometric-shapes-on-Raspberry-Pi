# -*- coding: utf-8 -*-
"""
Created on Wed Dec 13 12:13:07 2017

@author: liang
"""

import cv2
import numpy as np  

'''
确定图片原始长宽
二值化
可以利用描边的那个方法contour
确定图形的身高和宽度
找到四个点在矩阵中的位置
对图像进行切割
然后再缩小成32*32
'''
def draw_contour(ImgPath):
    #img = Image.open(ImgPath)
    img =ImgPath
    blured = cv2.blur(img,(5,5))    #进行滤波去掉噪声
    gray = cv2.cvtColor(blured,cv2.COLOR_BGR2GRAY)
    #定义结构元素 
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(50, 50))
    #开闭运算，先开运算去除背景噪声，再继续闭运算填充目标内的孔洞
    opened = cv2.morphologyEx(gray, cv2.MORPH_OPEN, kernel) 
    closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, kernel)
    seuil=np.max(np.array(gray))/2+np.min(np.array(gray))/2
    ret, binary = cv2.threshold(closed, seuil, 255, cv2.THRESH_BINARY)#binaire les valeurs des pixel
    image ,contours,hierarchy= cv2.findContours(binary,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)  
    #cnt = contours[4]
   # image_contour = cv2.drawContours(img, cnt, 0, (0,255,0), 3)
    image_contour = cv2.drawContours(img,contours,0,(24,81,172),10)
    print (len(contours))  
    return image_contour,closed

    
    
    
    
    