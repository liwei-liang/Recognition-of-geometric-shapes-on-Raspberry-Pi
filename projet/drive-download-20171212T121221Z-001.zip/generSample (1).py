# -*- coding: utf-8 -*-
"""
Created on Wed Dec  6 13:44:37 2017

@author: liang
 """
import os
from PIL import Image  
import numpy as np  
from skimage import measure

def processImage(filesoure, destsoure, name, imgtype):
    '''
    filesoure是存放待转换图片的目录
    destsoure是存在输出转换后图片的目录
    name是文件名
    imgtype是文件类型
    '''
    imgtype = 'png'

    #打开图片
    im = Image.open(filesoure + name)
    #缩放比例
    #im_resized = im.resize((32, 32), Image.ANTIALIAS)  
    #im_resized.save(destsoure + name, imgtype)
    #im_rotate = im_resized.rotate(30,False,True)

    for i in range (0, 72):#  1 to 10
        numero = i
        #im_rotate = im_resized.rotate(i*20,False,True)
        im_rotate = im.rotate(i*5,False,True)
        im_rotate = findMiddle(im_rotate)
        namer = name.split('.')[0] + "rotate"+ str(numero)+'.png'
        im_rotate.save(destsoure + namer, imgtype)

def findMiddle(img):    
    WHITE, BLACK = 255, 0
    #如果边界的颜色比较浅会直接变成边界的颜色
    img_gray = img.convert("L") #gray
    seuil=np.max(np.array(img_gray))/2
    img_2degree = img_gray.point(lambda x: WHITE if x > seuil else BLACK)
    
    contours = measure.find_contours(img_2degree, 0)
    
    right = 0
    left = 0
    bot = 0
    top = 0
    for n, contour in enumerate(contours):
        if right == 0 and left == 0 and bot == 0 and top == 0 :
            right = np.max(contour[:,1])
            left = np.min(contour[:,1])+1
            bot = np.max(contour[:,0])
            top = np.min(contour[:,0])+1
        if np.max(contour[:,1])>right:
            right = np.max(contour[:,1])
        if np.min(contour[:,1])<left:
            left = np.min(contour[:,1])+1
        if np.max(contour[:,0])>bot:
            bot = np.max(contour[:,0])
        if np.min(contour[:,0])<top:
            top = np.min(contour[:,0])+1
            
    hauteur = bot-top
    largeur = right-left
    
    if hauteur > largeur:
        line_middle = largeur/2+left
        left = line_middle - hauteur/2
        right = line_middle + hauteur/2
    elif hauteur < largeur:
        col_middle = hauteur/2+top
        top = col_middle - largeur/2
        bot = col_middle + largeur/2
     
    box = (left,top,right,bot) #设定裁剪区域  
        
    img_cut = img.crop(box)  #裁剪图片，并获取句柄region 
    
    img_resized = img_cut.resize((32, 32))     
    
    return img_resized

def main():
    #切换到源目录，遍历源目录下所有图片
    os.chdir(MyPath)
    for i in os.listdir(os.getcwd()):
        #检查后缀
        postfix = os.path.splitext(i)[1]
        if postfix == '.PNG' or postfix == '.png':
            processImage(MyPath, OutPath, i, postfix)

if __name__ == '__main__':
    MyPath =  "f:/sy26/projet/samplesOrigine/"
    OutPath = "f:/sy26/projet/total_sample/"
    main()