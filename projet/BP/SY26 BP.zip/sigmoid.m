function [ Y ] = sigmoid( X )
%SIGMOID Summary of this function goes here
%   Detailed explanation goes here
    Y = (1./(1+exp(-X)));

end

